Hello

This branch contains the inital commit of the Workspace application. This initial commit contains folders and files that I have added to help start the project.
I have added an "assets" folder and a "src" folder. The assets folder is used to store resources such as images and fonts, there is a photos file within it that
contains an example image for a Welcome page. The "src" folder holds multiple folders which help to organise the project. 

-First we have the components folder which will house any custom components that are created so far it has a  CustomButton file for a reuseable button. 

-We then have the routes folder. This folder is where the navigation routes of the app will be made and it contains a stack with 3 screens listed on it already.

-screens folder. This folder is where our screens for the application will be kept, it currently has 3 fils: Welcomescreen.js, Registerscreen.js and Homescreen.js

-utils folder. This folder will be used to keep useful pieces of code like a stylesheet or api helpers.

As of the initial commit the application will display the Welcomescreen and if the user presses on the text they will be taken to the Registerscreen where they can
enter their information and will be taken to the Homescreen if entered password is the same as the confirmation password.
