import * as React from "react";
import { StatusBar, StyleSheet } from "react-native";

const SearchTab = () => {
  return <StatusBar barStyle="default" />;
};

const styles = StyleSheet.create({});

export default SearchTab;
